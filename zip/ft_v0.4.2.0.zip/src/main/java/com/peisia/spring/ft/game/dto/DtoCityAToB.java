package com.peisia.spring.ft.game.dto;

import lombok.Data;

@Data
public class DtoCityAToB {
    int a;
    int b;
    int distance;
}