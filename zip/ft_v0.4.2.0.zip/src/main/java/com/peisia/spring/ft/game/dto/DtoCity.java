package com.peisia.spring.ft.game.dto;

import lombok.Data;

@Data
public class DtoCity {
	int no;
    String name;
    String bar_man_id;
    String bar_man_name;
    int bar_man_liking;
}