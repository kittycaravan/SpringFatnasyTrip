package com.peisia.spring.ft.game.service;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ServiceCmdImpl implements ServiceCmd {
	@Override
	public void proc(String cmd, ServiceStateInfo ssi) {
		log.info("==== 명령처리:"+cmd);
		switch(cmd) {
		case "drink":
			log.info("==== 명령처리:술집-술마심-5골드소모");
			ssi.updateGold(-5);
			break;
		case "drink2":
			log.info("==== 명령처리:술집-술 또 마심-10골드소모");
			ssi.updateGold(-10);
			break;
		}

	}

}
