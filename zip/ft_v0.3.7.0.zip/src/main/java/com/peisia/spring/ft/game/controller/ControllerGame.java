package com.peisia.spring.ft.game.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.ft.game.dto.Fleet;
import com.peisia.spring.ft.game.service.ServiceCmd;
import com.peisia.spring.ft.game.service.ServicePlayer;
import com.peisia.spring.ft.game.service.ServiceStateInfo;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/game/*")
@AllArgsConstructor
@Controller
@Log4j
public class ControllerGame {
	ServicePlayer servicePlayer;
	ServiceCmd serviceCmd;
	ServiceStateInfo serviceStateInfo;
	
	@GetMapping("/start")
	public void start() {
		
	}
	@GetMapping("/city")
	public void city(
			@RequestParam("loc") String loc, 
			@RequestParam(value = "cmd", required = false, defaultValue = "") String cmd, 
			Model m) {
		
		//todo
		//cmd 처리
		//cmd 를 먼저 처리하고 아래에서 정보를 다시 가져와 화면을 갱신하게 함
		serviceCmd.proc(cmd,serviceStateInfo);
		
		//디비에서 도시 공통 상단 상태 창 정보를 가져와서 모델에 담음.
		m.addAttribute("state", serviceStateInfo.getAll());
		
		//todo
		//모델 세팅
		m.addAttribute("loc", loc);
		m.addAttribute("cmd", cmd);
		
		
		
		
		//cmd 처리 후 다시 원 화면으로 돌아가는 구조임.
		
		//분기는 loc 값으로 알아서 됨
	}
	@GetMapping("/gameloading")
	public String gameloading(HttpSession s) {
		log.info("==== 게임 로딩중.... ====");
		
//		Fleet fleet = servicePlayer.init();
//		s.setAttribute("f", fleet);
//		s.setAttribute("test", "야옹이");
		return "redirect:/game/city?loc=city";
	}	
}