package com.peisia.spring.ft.game.service;

public interface ServiceCmd {
	public void proc(String cmd, ServiceStateInfo ssi);
}
