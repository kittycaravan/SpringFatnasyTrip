package com.peisia.spring.ft.service;

public interface Cmd {
	public void proc(String cmd);
}
