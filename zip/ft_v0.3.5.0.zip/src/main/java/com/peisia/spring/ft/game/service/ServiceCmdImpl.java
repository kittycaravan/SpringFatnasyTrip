package com.peisia.spring.ft.game.service;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ServiceCmdImpl implements ServiceCmd {
	@Override
	public void proc(String cmd) {

	}

}
