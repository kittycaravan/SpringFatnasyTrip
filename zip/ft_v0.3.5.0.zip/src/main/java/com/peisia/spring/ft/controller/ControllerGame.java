package com.peisia.spring.ft.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.ft.dto.game.Fleet;
import com.peisia.spring.ft.service.Cmd;
import com.peisia.spring.ft.service.Player;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/game/*")
@AllArgsConstructor
@Controller
@Log4j
public class ControllerGame {
	Player player;
	Cmd commend;
	
	@GetMapping("/start")
	public void start() {
		
	}
	@GetMapping("/city")
	public void city(
			@RequestParam("loc") String loc, 
			@RequestParam(value = "cmd", required = false, defaultValue = "") String cmd, 
			Model m) {
		//todo
		//모델 세팅
		m.addAttribute("loc", loc);
		m.addAttribute("cmd", cmd);
		
		//todo
		//cmd 처리
		commend.proc(cmd);
		
		
		
		//cmd 처리 후 다시 원 화면으로 돌아가는 구조임.
		
		//분기는 loc 값으로 알아서 됨
	}
	@GetMapping("/gameloading")
	public String gameloading(HttpSession s) {
		log.info("==== 게임 로딩중.... ====");
		Fleet fleet = player.init();
		s.setAttribute("f", fleet);
		s.setAttribute("test", "야옹이");
		return "redirect:/game/city?loc=city";
	}	
}