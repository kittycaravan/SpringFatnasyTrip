package com.peisia.spring.ft.service;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class CmdImpl implements Cmd {
	@Override
	public void proc(String cmd) {

	}

}
