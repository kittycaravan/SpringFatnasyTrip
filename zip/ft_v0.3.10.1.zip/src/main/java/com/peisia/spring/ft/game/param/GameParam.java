package com.peisia.spring.ft.game.param;

import lombok.Data;

@Data
public class GameParam {
	String loc;
	String cmd;
	String answer;
}
