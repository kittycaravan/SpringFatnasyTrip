package com.peisia.spring.ft.game.service;

import org.springframework.stereotype.Service;

import com.peisia.spring.ft.game.model.ModelCmdProc;
import com.peisia.spring.ft.game.param.GameParam;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ServiceCmdImpl implements ServiceCmd {
	@Override
	public ModelCmdProc proc(GameParam p, ServiceStateInfo ssi) {
		ModelCmdProc mcp = null;
		String cmd = p.getCmd();
		if(cmd!=null) {
			log.info("==== 명령처리:"+cmd);
			switch(cmd) {
			case "drink":
				log.info("==== 명령처리:술집-술마심-5골드소모");
				ssi.updateGold(-5);
				break;
			case "drink2":
				log.info("==== 명령처리:술집-술 또 마심-10골드소모");
				ssi.updateGold(-10);
				//todo
				//임시로 선물 보유 여부가 아닌 골드를 일정 이상 보유했는지로 분기 처리
				mcp = new ModelCmdProc();
				if(ssi.getAll().getGold() > 1000) {
					mcp.setMsg("어머 이게 뭐예요? 예쁘네요.");
					mcp.setChoices("준다","안준다");
					mcp.setAnswerProcCmdNames("yes","no");
				} else {
					mcp.setMsg("저, 들어봐요. 빅뉴스에요! 마르세이유에서 조금 세공이 유행할 것 같대요.");
				}
				break;
			case "drink3":
				log.info("==== 명령처리:술집-선물 주기/안주기");
				//선물을 줬는지 안줬는지 분기
				mcp = new ModelCmdProc();
				String answer = p.getAnswer();
				if(answer.equals("yes")) {
					ssi.updateGold(-100);
					log.info("==== 명령처리:술집-선물 줌");
					mcp.setMsg("고마워요!");
				} else {
					log.info("==== 명령처리:술집-선물 안줌");
					mcp.setMsg("참 예쁜데..");
				}
				break;
			}
		}
		return mcp; 
	}
}