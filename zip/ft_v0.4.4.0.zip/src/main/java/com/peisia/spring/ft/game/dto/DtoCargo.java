package com.peisia.spring.ft.game.dto;

import lombok.Data;

@Data
public class DtoCargo {
	int cargoNo;
	String goodsName;
	int goodsGrade;
	int purchasePrice;
}