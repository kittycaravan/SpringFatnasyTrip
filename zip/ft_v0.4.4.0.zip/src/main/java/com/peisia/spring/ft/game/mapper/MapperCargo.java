package com.peisia.spring.ft.game.mapper;

import java.util.ArrayList;

import com.peisia.spring.ft.game.dto.DtoCargo;

public interface MapperCargo {
	ArrayList<DtoCargo> getAll();
}
