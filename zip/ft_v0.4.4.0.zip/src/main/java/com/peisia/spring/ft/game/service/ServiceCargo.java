package com.peisia.spring.ft.game.service;

import java.util.ArrayList;

import com.peisia.spring.ft.game.dto.DtoCargo;

public interface ServiceCargo {
	ArrayList<DtoCargo> getAll(); 
}
