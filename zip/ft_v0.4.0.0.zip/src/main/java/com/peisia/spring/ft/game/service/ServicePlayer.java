package com.peisia.spring.ft.game.service;

import com.peisia.spring.ft.game.dto.Fleet;

public interface ServicePlayer {
	public Fleet init();
}
