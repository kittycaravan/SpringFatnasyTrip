package com.peisia.spring.ft.game.param;

import lombok.Data;

@Data
public class Param {
	String loc;
	String cmd;
	String answer;
}
