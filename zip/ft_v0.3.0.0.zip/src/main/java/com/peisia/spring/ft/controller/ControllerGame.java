package com.peisia.spring.ft.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.animal.Cat;

import lombok.AllArgsConstructor;

@RequestMapping("/game/*")
@AllArgsConstructor
@Controller
public class ControllerGame {
	Cat kitty;
	@GetMapping("/start")
	public void start() {
		
	}
	@GetMapping("/city")
	public void city(@RequestParam("loc") String loc, Model m) {
		//todo
		//모델 세팅
		m.addAttribute("loc", loc);
		
		//todo
		//분기
//		return "game/"+loc;
	}
}