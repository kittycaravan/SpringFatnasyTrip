package com.peisia.animal;

public interface Cat {
	void eat();
}