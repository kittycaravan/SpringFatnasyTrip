package com.peisia.spring.ft.game.dto;

public class Product {

}
