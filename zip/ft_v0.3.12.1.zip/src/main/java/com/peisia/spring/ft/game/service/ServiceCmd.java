package com.peisia.spring.ft.game.service;

import com.peisia.spring.ft.game.model.ModelCmdProc;
import com.peisia.spring.ft.game.param.GameParam;

public interface ServiceCmd {
//	public ModelCmdProc proc(String cmd, ServiceStateInfo ssi);
	public ModelCmdProc proc(GameParam p, ServiceStateInfo ssi);
}
