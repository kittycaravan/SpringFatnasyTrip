package com.peisia.animal;

import org.springframework.stereotype.Component;

@Component
public class Water {		
	public void provide() {	
		System.out.println("물을 줍니다.");
	}	
}		
