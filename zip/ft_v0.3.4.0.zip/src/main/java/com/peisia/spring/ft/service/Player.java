package com.peisia.spring.ft.service;

import com.peisia.spring.ft.dto.game.Fleet;

public interface Player {
	public Fleet init();
}
