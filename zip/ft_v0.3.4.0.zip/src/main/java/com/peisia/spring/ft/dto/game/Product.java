package com.peisia.spring.ft.dto.game;

public class Product {

}
