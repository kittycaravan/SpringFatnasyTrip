package com.peisia.animal;

import org.springframework.stereotype.Component;

@Component
public class Bowl {		
	public void prepare() {	
		System.out.println("고양이 접시를 준비합니다.");
	}	
}		
