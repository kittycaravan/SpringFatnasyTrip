package com.peisia.spring.ft.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.peisia.animal.Cat;

import lombok.AllArgsConstructor;

@RequestMapping("/di/*")
@AllArgsConstructor
@Controller
public class ControllerDiTest {
	Cat kitty;
	@GetMapping("/test")
	public void test() {
		kitty.eat();
	}
}