package com.peisia.animal;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;

@Component
@AllArgsConstructor	// 생성자를 통한 의존성 주입
public class CatImpl implements Cat{
	private Water water;
	private Food food;
	private Bowl bowl;
	
	public void eat() {
		water.provide();
		food.provide();
		bowl.prepare();
		System.out.println("물과 사료를 고양이 접시에 담아두고 고양이가 먹습니다.");
	}
}