package com.peisia.animal;

import org.springframework.stereotype.Component;

@Component
public class Food {		
	public void provide() {	
		System.out.println("사료를 줍니다.");
	}	
}		
