package com.peisia.spring.ft.game.service;

import org.springframework.stereotype.Service;

import com.peisia.spring.ft.game.model.ModelCmdProc;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class ServiceCmdImpl implements ServiceCmd {
	@Override
	public ModelCmdProc proc(String cmd, ServiceStateInfo ssi) {
		ModelCmdProc mcp = null;
		log.info("==== 명령처리:"+cmd);
		switch(cmd) {
		case "drink":
			log.info("==== 명령처리:술집-술마심-5골드소모");
			ssi.updateGold(-5);
			break;
		case "drink2":
			log.info("==== 명령처리:술집-술 또 마심-10골드소모");
			ssi.updateGold(-10);
			mcp = new ModelCmdProc("어머 예뻐요. 이거 저 주실 수 있나요?");
			//todo
			//대화 동시에 명령 처리하기
			
			//대화의 흐름은 이어가야하고
			//처리도 해야함.
			//처리의 종류는 n가지 n개
			
			break;
		}
		
		return mcp; 

	}

}
