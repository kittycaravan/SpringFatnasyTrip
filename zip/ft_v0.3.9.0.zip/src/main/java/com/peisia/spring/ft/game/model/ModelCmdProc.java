package com.peisia.spring.ft.game.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

/* 명령처리모델(화면에 출력이나 입력을 받을게 있는 경우 이 객체에 데이터를 실어 보낸다) */
public class ModelCmdProc {
	//todo
	String msg;
	
}
