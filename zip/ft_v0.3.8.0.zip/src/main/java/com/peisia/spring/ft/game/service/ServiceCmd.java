package com.peisia.spring.ft.game.service;

import com.peisia.spring.ft.game.model.ModelCmdProc;

public interface ServiceCmd {
	public ModelCmdProc proc(String cmd, ServiceStateInfo ssi);
}
